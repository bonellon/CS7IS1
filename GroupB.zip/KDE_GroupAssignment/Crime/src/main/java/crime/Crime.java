/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crime;

/**
 *
 * @author Nicky
 */
public class Crime {

    String Name;
    int MurderCount, RobberyCount, GovernmentCount, DangerousCount, DrugCount, 
            PropertyCount, PublicCount, TheftCount, FraudCount, WeaponsCount, 
            BurglaryCount, KidnappingCount;

    public Crime() {

    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getMurderCount() {
        return MurderCount;
    }

    public void setMurderCount(int MuderCount) {
        this.MurderCount = MuderCount;
    }

    public int getRobberyCount() {
        return RobberyCount;
    }

    public void setRobberyCount(int RobberyCount) {
        this.RobberyCount = RobberyCount;
    }

    public int getGovernmentCount() {
        return GovernmentCount;
    }

    public void setGovernmentCount(int GovernmentCount) {
        this.GovernmentCount = GovernmentCount;
    }

    public int getDangerousCount() {
        return DangerousCount;
    }

    public void setDangerousCount(int DangerousCount) {
        this.DangerousCount = DangerousCount;
    }

    public int getDrugCount() {
        return DrugCount;
    }

    public void setDrugCount(int DrugCount) {
        this.DrugCount = DrugCount;
    }

    public int getPropertyCount() {
        return PropertyCount;
    }

    public void setPropertyCount(int PropertyCount) {
        this.PropertyCount = PropertyCount;
    }

    public int getPublicCount() {
        return PublicCount;
    }

    public void setPublicCount(int PublicCount) {
        this.PublicCount = PublicCount;
    }

    public int getTheftCount() {
        return TheftCount;
    }

    public void setTheftCount(int TheftCount) {
        this.TheftCount = TheftCount;
    }

    public int getFraudCount() {
        return FraudCount;
    }

    public void setFraudCount(int FraudCount) {
        this.FraudCount = FraudCount;
    }

    public int getWeaponsCount() {
        return WeaponsCount;
    }

    public void setWeaponsCount(int WeaponsCount) {
        this.WeaponsCount = WeaponsCount;
    }

    public int getBurglaryCount() {
        return BurglaryCount;
    }

    public void setBurglaryCount(int BurglaryCount) {
        this.BurglaryCount = BurglaryCount;
    }

    public int getKidnappingCount() {
        return KidnappingCount;
    }

    public void setKidnappingCount(int KidnappingCount) {
        this.KidnappingCount = KidnappingCount;
    }
}
