# CS7IS1 - Group B Assignment
Github Repository: https://github.com/bonellon/CS7IS1

Documentation under Documentation/Knowledge engineering report.pdf
Self reflection: Documentation/SelfReflectionReport.pdf
LODE : Irish Crime Statistics by Station.html
VOWL Representation: VOWL.png

1. Uplifting Dataset

>> Run Crime\src\main\java\crime\CSV2RDFConversion.java

2. Creating the ontology 

>> Run Crime\src\main\java\crime\CreateModel.java\crime\CreateModel.java

>>Ontology will be created in crime\CrimeOntology.owl


3. Running Query UI

>> Run Crime\src\main\java\crime\KDEFrontEnd.java